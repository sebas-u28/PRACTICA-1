using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Primera_pc_Teoria.Models
{
    public class Boleta
    {
        string? Nombre { get; set; }
        string? Apellido { get; set; }
        string? Dni { get; set; }
    }
}